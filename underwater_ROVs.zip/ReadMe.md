# Underwater ROV WeBots simulation

Here's a simulation I wrote in WeBots with a Python controller for UCL Mech0019: Ocean Engineering Fundamentals. In the wake of the current situation, we were not able to compete with our vehicles in a Seaperch style challenge, so it helped to see how the vehicle may have behaved!

Find the demo here: https://youtu.be/O_Oaaerdkf8
